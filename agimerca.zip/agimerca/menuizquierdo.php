<div class="list-group">
		   <a href="#" class="list-group-item thumbnail">
				<img width="300" src="<?php echo $_SESSION["img_perfil"]; ?>" alt="Imagen perfil">
			</a>
		  <a href="cambiar_clave.php" class="list-group-item">Cambiar Contrase&ntilde;a</a>
		  <a href="galeria_imagenes.php" class="list-group-item">Ver albunes</a>
		  <a href="galeria_videos.php" class="list-group-item">Mis videos</a>
		  <a href="publicaciones.php" class="list-group-item">Mis publicaciones</a>
		</div>