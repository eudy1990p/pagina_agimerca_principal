    </div> <!-- /container -->


    <footer class="footer">
      <div class="container">
        <p class="text-muted"><a href="http://eudy.260mb.net"><?php echo $label->FooterDerechos; ?></a></p>
      </div>
    </footer>



    <script src="js/bootstrap.min.js"></script>
    <!--<script src="js/docs.min.js"></script>-->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>